# @lazyai/generation-ui-vue

声明式 Generation UI 的 Vue 3 渲染组件。组件只负责渲染白名单 UISpec、维护表单输入并抛出 Action，不直接调用大模型、Agent 或 MCP Server。

当前版本：`0.5.2`。本包适用于 Vue `3.5+`、PrimeVue `4.5+`、PrimeIcons `7+` 和 Chart.js `4.4+`，包格式为 ESM。

## 安装

```bash
npm install ./lazyai-generation-ui-vue-0.5.1.tgz
npm install vue@^3.5 primevue@^4.5 primeicons@^7 @primeuix/themes@^1.2 chart.js@^4.4
```

在宿主 Vue 3 应用中初始化 PrimeVue：

```ts
import { createApp } from "vue";
import PrimeVue from "primevue/config";
import Aura from "@primeuix/themes/aura";
import "primeicons/primeicons.css";
import App from "./App.vue";

createApp(App)
  .use(PrimeVue, { theme: { preset: Aura } })
  .mount("#app");
```

## 使用

```vue
<script setup lang="ts">
import { ref } from "vue";
import {
  GenerationUiRenderer,
  type GenerationUiActionEvent,
  type UISpec,
} from "@lazyai/generation-ui-vue";
import "@lazyai/generation-ui-vue/style.css";

const props = defineProps<{
  spec: UISpec;
  data: Record<string, unknown>;
}>();

const form = ref<Record<string, unknown>>({ ...props.spec.form_defaults });
const busyAction = ref<string | null>(null);

async function handleAction(event: GenerationUiActionEvent) {
  busyAction.value = event.actionId;
  try {
    await fetch("/api/ui/actions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action_id: event.actionId,
        arguments: event.arguments,
      }),
    });
  } finally {
    busyAction.value = null;
  }
}
</script>

<template>
  <GenerationUiRenderer
    :spec="spec"
    :data="data"
    v-model:form="form"
    :busy-action="busyAction"
    @action="handleAction"
  />
</template>
```

## 对外接口

### 交互模式

UISpec 可以通过 `interaction_mode` 限制能力：

| 模式 | 能力 |
|---|---|
| `read_only` | 只展示数据，不允许表单或外部 Action |
| `local_preview` | 允许本地填写和预览，不向外抛出 Action |
| `host_action` | 允许抛出服务端白名单 Action |

当前对模型开放 55 个白名单组件。`0.3.0` 新增 `Grid`、`SplitLayout`、`Stepper`、`Breadcrumb`、`Avatar`、`SafeImage`、`Tree`、`StatComparison`、`Gauge`、`Pagination`、`Skeleton`、`AutoComplete`、`InputMask`、`RangeSlider` 和 `ChipSelect`。`0.3.1` 增加结构化选项兼容。`0.4.0` 新增本地切换的 `Sidebar`，并允许缺少业务数据时安全渲染空状态页面。`0.4.1` 新增通用 `ComparisonTable`。`0.5.0` 增加对比列选择、只看差异、选择状态回传，并进一步统一多行标签、控件和帮助文字的对齐方式。`0.5.1` 增加受控条件输入，用于“选择其他后再填写”等安全表单流程。`0.5.2` 为 `NumberInput` 增加 `step` 和 `maxFractionDigits`，支持受控小数输入。

`ComparisonTable` 只展示宿主或 Agent 已经提供的 2–4 个结构化对象，不会自行搜索或生成商品、报价等业务数据。开启 `interactive` 后，可以进行候选高亮和差异筛选；配置 `selectionModel` 后，选中项会通过 `update:form` 回传宿主。

`SafeImage` 只接受后端数据中的 HTTPS 地址；`Stepper`、`Pagination` 和通用筛选输入只改变本地状态。密码及验证码组件只能用于 `local_preview`，且不允许预填。

### Props

| 参数 | 类型 | 必填 | 说明 |
|---|---|---:|---|
| `spec` | `UISpec` | 是 | 后端校验通过的白名单组件树 |
| `data` | `Record<string, unknown>` | 是 | 组件通过 `props.path` 读取的展示数据 |
| `form` | `Record<string, unknown>` | 否 | 用户填写状态，支持 `v-model:form` |
| `busyAction` | `string \| null` | 否 | 正在执行的 Action ID |
| `showHeader` | `boolean` | 否 | 是否显示标题、摘要和工具标签，默认显示 |

### Events

- `update:form`：任何输入变化后返回完整表单状态。
- `action`：用户点击白名单 Action 后返回：

```ts
interface GenerationUiActionEvent {
  actionId: string;
  action: UIActionDefinition;
  arguments: Record<string, unknown>;
}
```

宿主负责二次确认、权限判断、请求自己的后端和展示执行结果。组件不会直接访问业务工具。

## 数据协议

组件接收的内容必须分开保存：

| 数据 | 用途 |
|---|---|
| `spec` | 已由后端验证的组件树、交互模式和 Action 定义 |
| `data` | 指标、表格、列表和图表等只读业务数据 |
| `form` | 用户当前填写或选择的状态 |

推荐的 Agent 消息结构：

```json
{
  "type": "generation_ui",
  "conversation_id": "conv_001",
  "message_id": "msg_001",
  "artifact_id": "ui_001",
  "spec": {},
  "data": {}
}
```

普通文字消息继续使用 `type: "text"`。Renderer 不负责判断使用哪种消息类型。

## 原生 HTML 宿主

本包不是无依赖的 `<script>` 文件。原生 HTML/CSS/JavaScript 页面需要先进入 npm/Vite 构建流程，然后在每条 Generation UI 消息的 DOM 节点中局部创建 Vue App：

```text
原生聊天页面
  → generation-ui-bridge.js
  → createApp()
  → GenerationUiRenderer
```

每条 UI 消息应拥有独立实例，并由宿主实现 `mount / update / destroy`。消息删除或整个列表重绘前必须卸载对应 Vue App。

逐个组件出现和“重看生成过程”不是 Renderer 的 Props，而是宿主 Bridge 在收到并验证完整 UISpec 后，逐步传入裁剪后的组件树实现的。它不是模型 Token 级流式输出。

完整的原生 HTML、FastAPI Agent、消息协议、Bridge 代码、错误降级和验收步骤见随交付物提供的 `组件交付与原生HTML-Agent接入指南.md`。

## 宿主 Action 要求

宿主收到 `action` 后应：

1. 根据 `action.confirm` 决定是否二次确认。
2. 生成 `idempotency_key`，避免重复提交。
3. 将 `artifact_id`、`conversation_id`、`scenario`、`action_id` 和 `arguments` 发送到自己的后端。
4. 后端只信任 `action_id`，重新查询服务端注册的工具、权限和确认等级。
5. 成功后更新 `data` 或 `spec`；失败时保留当前表单。

不要根据浏览器提交的 `action.tool` 直接执行 MCP 工具。

## 状态与错误

- 使用 `artifact_id` 保存每条消息的 `form`，以支持页面切换后恢复。
- `PasswordInput` 和 `InputOtp` 只能用于 `local_preview`，不得预填或持久化。
- 后端失败时向用户展示自然语言 `user_message`，把 `technical_detail` 留在调试日志。
- UISpec 验证失败时不要用无关业务页面兜底；可以重试或退回普通文本消息。
- `busyAction` 只负责按钮执行中状态，不代表后端一定成功。

推荐错误结构：

```json
{
  "detail": {
    "code": "UI_GENERATION_FAILED",
    "user_message": "这次界面没有生成成功，你可以重试或改用文字回答。",
    "technical_detail": "仅写入受限日志",
    "recoverable": true,
    "suggestions": ["重新生成界面", "改用文字回答"]
  }
}
```

## 版本升级

`0.5.1` 相对 `0.5.0`：

- 保持原有 `GenerationUiRenderer` Props 和 Events 兼容。
- 支持服务端校验后的 `visibleWhen` 条件输入。
- 修复候选值与手动输入并存时的提交歧义。

使用 tgz 文件依赖时，替换文件并重新执行 `npm install`；企业项目应锁定明确版本。

当前包的 `license` 为 `UNLICENSED`，仅按内部授权范围分发；公开发布或向外部组织交付前应先确认许可证和知识产权授权。

## 安全边界

- UISpec 必须先由后端完成 JSON Schema 和白名单校验。
- Action 的 ID、工具名、确认级别必须由后端注册表覆盖，不能信任模型原始值。
- `arguments` 同时保留结构化数据；可由 Agent Adapter 再生成易读文本，但不要只保留文本。
- 组件包中不包含 API Key、模型地址和后端接口地址。
- `local_preview` 不会抛出外部 Action；宿主也不应持久化其中的密码或验证码。
